/** Automatically generated file. DO NOT MODIFY */
package com.example.photojournal;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}